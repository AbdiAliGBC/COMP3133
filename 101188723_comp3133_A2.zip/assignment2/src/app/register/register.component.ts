import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private Auth: AuthService){}
    
  ngOnInit() {
  }
  register(event: any){
    event.preventDefault()
    const target=  event.target;
    const username= target.querySelector('#username').value
    const password= target.querySelector('#password').value
    this.Auth.getUserDetails(username,password)
  console.log(username,password)
  }

}
