const express = require('express');
const mongoose = require('mongoose');
const TypeDefs = require('./schema');
const Resolvers = require('./resolvers');
const bodyParser = require('body-parser');
const cors = require('cors');
const { ApolloServer } = require('apollo-server-express');


var dbUrl="mongodb+srv://root:admin@cluster0.stcef.mongodb.net/assignment1?retryWrites=true&w=majority"


//mongoDB Atlas Connection String

//Connect to mongoDB Atlas
const connect = mongoose.connect(dbUrl, 
{ 
      useNewUrlParser: true,
      useUnifiedTopology: true
});

connect.then((db) => {
      console.log('Connected correctly to server!');
}, (err) => {
      console.log(err);
});

//Define Apollo Server
const server = new ApolloServer({
      typeDefs: TypeDefs.typeDefs,
      resolvers: Resolvers.resolvers
});

//Define Express Server
const app = express();
app.use(bodyParser.json());
app.use('*', cors());
server.applyMiddleware({ app });
app.listen({ port:4000}, () =>
  console.log(`🚀 Server ready at http://localhost:4000${server.graphqlPath}`));