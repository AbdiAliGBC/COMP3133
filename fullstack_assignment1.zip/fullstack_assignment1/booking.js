const mongoose = require('mongoose');
var date= new Date ()

const BookingSchema = new mongoose.Schema({
  hotel_id:{
      type: Number,
      required: true,
  },
  booking_date:{
    type: String,
    default: (date.getMonth()+1)+"-"+date.getDate()+"-"+date.getFullYear()
  },
  booking_start:{
    type: String,
    required: true,
    validate: function(val){
      const dateformat=/\d{2}-\d{2}-\d{4}/
      return dateformat.test(val)
    }
  },
  booking_end:{
    type: String,
    required: true,
    validate: function(val){
      const dateformat=/\d{2}-\d{2}-\d{4}/
      return dateformat.test(val)
    }
  },

  user_id:{
    type: Number,
    required: true,
    unique: true,
  }

});

const Booking = mongoose.model("Booking", BookingSchema);
module.exports = Booking;