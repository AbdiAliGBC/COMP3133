const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  user_id:{
      type: Number,
      required: true,
      unique: true,
  },

  username:{
      type: String,
      required: [true,"Username must be unique"],
      unique: true,
  },
  password:{
      type: String,
      required: true,
  },

  email:{
      type: String,
      required: [true,"Email must be unique"],
      unique: true,
  }

});

const User = mongoose.model("User", UserSchema);
module.exports = User;