import { Component, OnInit } from '@angular/core';
import {SpacexapiService} from '../network/spacexapi.service';

@Component({
  selector: 'app-missionlist',
  templateUrl: './missionlist.component.html',
  styleUrls: ['./missionlist.component.css']
})
export class MissionlistComponent implements OnInit {
  missionArray = [];
  constructor(private spacexApi: SpacexapiService) { }

  ngOnInit(): void {
    this.getAllLaunches();
  }

  getAllLaunches(): any {
    this.spacexApi.getLaunches()
    .subscribe((response:any) => {
      console.log(response);
      this.missionArray = response;
    },
    err =>{
      console.log(err);
    })
  }

}
